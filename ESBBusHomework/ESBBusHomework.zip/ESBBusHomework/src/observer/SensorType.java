package observer;

public enum SensorType {
    CO2,
    NO2
}
