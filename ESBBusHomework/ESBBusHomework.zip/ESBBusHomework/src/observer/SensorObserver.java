package observer;

import java.util.List;

public interface SensorObserver {
    void update(List<String> data);
}
